document.addEventListener('DOMContentLoaded', function() {
    var accordionItems = document.querySelectorAll('.accordion-item');
  
    accordionItems.forEach(function(item) {
      var header = item.querySelector('.accordion-header');
      var content = item.querySelector('.accordion-content');
  
      header.addEventListener('click', function() {
        // Verifica se o item está aberto ou fechado
        var isOpen = item.classList.contains('open');
  
        // Fecha todos os itens antes de abrir o item clicado
        accordionItems.forEach(function(item) {
          item.classList.remove('open');
          item.querySelector('.accordion-content').style.display = 'none';
        });
  
        // Alterna a classe 'open' no item clicado e exibe/oculta o conteúdo
        if (isOpen) {
          item.classList.remove('open');
          content.style.display = 'none';
        } else {
          item.classList.add('open');
          content.style.display = 'block';
        }
      });
    });
  });