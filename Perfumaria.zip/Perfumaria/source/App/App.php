<?php

namespace Source\App;

class App
{
    public function home()
    {
        echo "Olá, Mundo!";;
    }

}
