<?php

namespace Source\App;

use League\Plates\Engine;
use Source\Models\User;

class Web
{

    private $view;

    public function __construct ()
    {
        $this -> view = new Engine(__DIR__ . "/../../themes/web","php");
    }

    public function home()
    {
        echo $this->view->render("home",[]);
    }

     public function register()
    {
    
        echo $this->view->render("register", []);
    }


    public function faq()
    {
       
       echo $this -> view->render("faq",[
        "faqs" => $faqs->selectAll()
       ]);

    }


    public function about (){
      
        echo $this -> view->render("about",[]);
    
    }

    public function chart (){
        
        echo $this -> view->render("chart",[]);
   
    }

    public function sale (){
        echo $this -> view->render("sale",[]);
    }

    

}
