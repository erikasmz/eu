<?php

const CONF_DB_HOST = "localhost";
const CONF_DB_USER = "root";
const CONF_DB_PASS = "";
const CONF_DB_NAME = "bd_escola_tarde"; // aqui deve ser alterado para o nome do banco de dados


const CONF_URL_BASE = "http://www.localhost/Perfumaria"; // para produção
const CONF_URL_TEST = "http://www.localhost/Perfumaria"; //  para teste
