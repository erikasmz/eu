<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <!-- or -->
    <link rel="stylesheet"
    href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
  <title>Aromas Celestiais</title>
  <link rel="stylesheet" href="<?= url ("assets/web/css/styles.css"); ?>">
</head>
<body>
  <header>
  <a href="#" class="logo">
    <i class='bx bx-chevrons-right'></i></i>Aromas Celestiais</a>
      
    <nav>

      <ul class="navegação">
      <li><a href="<?= url ("/"); ?>">Inicio</a></li>
      <li><a href="<?= url ("sale"); ?>">Ofertas</a></li>
        <li><a href="<?= url ("about"); ?>">Sobre</a></li>
        <li><a href="<?= url ("faq"); ?>">FAQ</a></li>
        <li><a href="<?= url ("register"); ?>">Cadastro</a></li>
      </ul>

    </nav>
    <div class="header-icons">
            <i class='bx bx-cart'></i>
            <div id="menu"><i class='bx bx-menu'></i></div>
        </div><!--header-icons-->
  </header>
  

  <main>
    <?= $this->section("content"); ?>
  </main>


</body>
</html>

