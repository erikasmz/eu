<?php
$this->layout ("_theme");
?>

