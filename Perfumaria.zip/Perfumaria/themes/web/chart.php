<?php
$this->layout ("_theme");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Carrinho de Compras</title>
  <style>
    /* Estilos para o carrinho de compras */
    .cart {
      width: 300px;
      border: 1px solid #ccc;
      padding: 10px;
    }

    .cart-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }

    .item-name {
      flex-grow: 1;
    }

    .item-price {
      margin-left: 10px;
    }

    .total {
      font-weight: bold;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="cart">
    <h2>Carrinho de Compras</h2>

    <div class="cart-item">
      <div class="item-name">Item 1</div>
      <div class="item-price">$10.00</div>
    </div>

    <div class="cart-item">
      <div class="item-name">Item 2</div>
      <div class="item-price">$15.00</div>
    </div>

    <div class="cart-item">
      <div class="item-name">Item 3</div>
      <div class="item-price">$20.00</div>
    </div>

    <div class="total">
      Total: $45.00
    </div>
  </div>
</body>
</html>