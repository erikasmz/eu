<?php
$this->layout ("_theme");

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?= url ("assets/web/css/faq.css"); ?>">
  <script type="text/javascript" src="<?= url ("assets/web/js/faq.js"); ?>" async></script>
  <title>FAQ</title>
</head>
<body>
</body>
</html>

<?php

  echo "<p><h3>Perguntas + Frequentes<h3></p>";

  if (!empty($faqs)){
    foreach($faqs as $faqs){
      echo "<div><br><h4>{$faq->question}</h4></br></div>";
      echo "<div>{$faq->$answer}</div>";
    }
  }
?>