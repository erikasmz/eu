<!DOCTYPE html>
<html>
<head>
  <title>Pagina de Cadastro</title>
  <link rel="stylesheet" href="<?= url ("assets/web/css/register.css"); ?>">
  <script type="text/javascript" src="<?= url ("assets/web/js/register.js"); ?>" async></script>
 
</head>
<body>
    
        <div class="container">
            
          <form method="post" action="cadsubmit.php" id="cadastro"class="card">
    
          <!-- manda o form para o cadsubmit-->
    
            <h1>Cadastrar</h1>
    
            <div id="msgError"></div>
            <div id="msgSuccess"></div>
    
            <div class="label-float">
              <input type="text" id="nome" name="nome" placeholder=" " required />
              <label id="labelNome" for="nome">Nome</label>
            </div>
    
            <div class="label-float">
              <input type="text" id="usuario" name="usuario" placeholder=" " required />
              <label id="labelUsuario" for="usuario">Usuário</label>
            </div>
    
            <div class="label-float">
              <input type="password" id="senha" name="senha" placeholder=" " required />
              <label id="labelSenha" for="senha">Senha</label>
              <i id="verSenha" class="fa fa-eye" aria-hidden="true"></i>
            </div>
    
            <div class="label-float">
              <input type="password" id="confirmSenha" placeholder=" " required />
              <label id="labelConfirmSenha" for="confirmSenha"
                >Confirmar Senha</label
              >
              <i id="verConfirmSenha" class="fa fa-eye" aria-hidden="true"></i>
            </div>
    
            <div class="justify-center">
              <button type="submit" onclick="cadastrar()" >Cadastrar</button>
            </div>
            
            <div class="justify-center">
                  <hr />
                </div>
        
                <p>
                  Já tem uma conta?
                  <a href="login.php">
                    Faça login
                  </a>
                </p>
              </div>
            </form>
        </div>
    
      
    
       
</body>
</html>