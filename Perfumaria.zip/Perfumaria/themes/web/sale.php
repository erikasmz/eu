<?php
$this->layout ("_theme");
?>

<section>
        <h2>Ofertas</h2>
        <div class="product">
          <img src="<?= url ("/assets/web/images/img1.png"); ?>" alt="Blooming-rose">
          <h3>Blooming rose</h3>
          <p>De: R$ 150,50</p>
          <p>Por: R$ 119,92</p>
          <button>Comprar</button>
        </div>
        
        <div class="product">
          <img src="<?= url ("/assets/web/images/img2.png"); ?>" alt="Goldman">
          <h3>Amouage Goldman</h3>
          <p>De: R$ 133,70</p>
          <p>Por: R$ 109,90</p>
          <button>Comprar</button>
        </div>

        <div class="product">
          <img src="<?= url ("/assets/web/images/img3.png"); ?>" alt="Ralph-Lauren">
          <h3>Ralph Lauren Ralph´S Club</h3>
          <p>De: R$ 599,00</p>
          <p>Por: R$ 479,90</p>
          <button>Comprar</button>
        </div>
        
        <!-- Adicione mais produtos aqui -->
        
      </section>